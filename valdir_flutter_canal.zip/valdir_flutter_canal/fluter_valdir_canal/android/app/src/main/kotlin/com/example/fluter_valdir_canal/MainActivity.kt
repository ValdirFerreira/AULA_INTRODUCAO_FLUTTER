package com.example.fluter_valdir_canal

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
